/*******************************************************************************
* \file main.c
* \brief This file is used to demonstrate the TFTSHIELD API.
*
* Version 1.0
*
* \author Robert Barron
*
* \bug 
*******************************************************************************/
#include <project.h>

int main()
{   
    //intializes tft
    TFTSHIELD_1_Start();
    
    TFTSHIELD_1_FillScreen(BLACK);
    //start at 0,0 for text
    TFTSHIELD_1_SetCursor(0, 0);
    TFTSHIELD_1_SetTextColor(WHITE);  
    TFTSHIELD_1_SetTextSize(2);
    
    //landscape orientation
    TFTSHIELD_1_SetRotation(1);
    TFTSHIELD_1_PrintString("tft lcd screen with word wrap working blah blah blah");
    
    TFTSHIELD_1_DrawLine(50, 150, 100, 150, GREEN);
    TFTSHIELD_1_DrawLine(35, 100, 35 , 200, BLUE);
    
    TFTSHIELD_1_FillRect(150, 150, 75,75, YELLOW);
    
    for(;;)
    {
        /* Place your application code here. */
    }
}

/* [] END OF FILE */
